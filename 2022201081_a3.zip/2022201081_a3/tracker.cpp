#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <pthread.h>
// #include <string>
#include <iostream>
#include <string>
#include <bits/stdc++.h>
#include <curses.h>
#include <sstream>

using namespace std;

struct user_struct
{
    int available;
    string password;
    string name;
};


struct group_struct
{
    int users;
    string group_id;
    string admin_name;
    unordered_map<string,bool> file_shareable; // perticular file is shareable or not
    vector< pair <string, string> > file_names; //list of files and location in perticular group
    vector<int> clients;
    vector<string> users_name;
    // unordered_map<int,string> users_name; //client_no-->key and value-->userid
};

struct user
{
    // vector<int> client_no;
    vector<string> user_id;
};

struct share_tracker
{
    vector< pair <string,string> > vec;
};


unordered_map<int,share_tracker> track;
unordered_map<string, user> group_requests;
unordered_map<int,string> current_users; // storing logged in users client no and userid
unordered_map<string, user_struct> db; // storing username and password
unordered_map<string, group_struct> db_group; // storing group info
// unordered_map<int, string> group_requests; // request to join group with client_no and userid

void* handle_connection(void* pclient_socket);
int check(int exp, const char *msg);


int server_socket;
int client_socket[9];
pthread_t th[9];

void *exit_func(void *x)
{
    string to_quit;
    cin >> to_quit;
    if (to_quit == "quit")
        exit(-1);
}

int main(int argc, char *argv[])
{
    // FILE *file_pointer;
    // char c;
    // file_pointer = fopen("try.txt","r");

    // if(argc <= 2)
    // {
    //     cout<<"Enter filename and tracker_no";
    //     exit(-1);
    // }

    char * line = NULL;
    size_t size = 0;
    ssize_t read;

    FILE *fp;
    fp = fopen(argv[1],"r");
    if (fp == NULL)
    exit(EXIT_FAILURE);

    getline(&line, &size, fp);
    char retrieve = line[0];
    string ip="",port="";
    int le=1;
    while(retrieve != '\n')
    {
        if(retrieve == 'p')
        {
            retrieve = line[le];
            if(retrieve == ':')
            {
                while (retrieve != ' ')
                {
                    le++;
                    retrieve = line[le];
                    ip.push_back(retrieve);
                }
                
            } 
        }

        if(retrieve == 't')
        {
            retrieve = line[le];
            if(retrieve == ':')
            {
                while (retrieve != ' ')
                {
                    le++;
                    retrieve = line[le];
                    port.push_back(retrieve);
                }
                
            } 
        }
        retrieve = line[le];
        le++;
    }

    stringstream geek(port);
    int port_no = 0;
    geek >> port_no;
    fclose(fp);


    // int size = 30;
    // char* ip = (char*)malloc(sizeof(char) * size);
    // ip ="127.0.0.1";
    const char *ip_addr = ip.c_str();
    // const char *add = ip.c_str();
    // int port = 5000;

    // int client_socket;
    struct sockaddr_in s_address,c_address;
    socklen_t address_size;
    char message[512];

    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if(server_socket<=-1)
    {
        perror("Error");
        exit(1);
    }
    printf("Server created\n");

    memset(&s_address,'\0', sizeof(s_address));

    s_address.sin_family = AF_INET;
    s_address.sin_port=port_no;
    s_address.sin_addr.s_addr = inet_addr(ip_addr);


    int x = bind(server_socket, (struct sockaddr*)&s_address, sizeof(s_address));
    printf("Binded to %d port number\n",port_no);


    listen(server_socket,5);

    // pthread_t t_arr[60];
    pthread_attr_t attr;
    pthread_attr_init(&attr);

    int client_no = 0;

    pthread_t t;
    pthread_create(&t, NULL, exit_func, NULL);

    while(client_no < 9)
    {
        address_size = sizeof(c_address);
        client_socket[client_no] = accept(server_socket,  (struct sockaddr*)&c_address, &address_size);
        printf("Client connected\n");

        // pthread_t th;
        int *pclient = (int *)malloc(sizeof(int));
        *pclient = client_socket[client_no];
        pthread_create(&th[client_no], &attr, handle_connection, pclient);
        client_no++;
    }

    

    for(int i=0;i<9;i++)
    {
        pthread_join(th[i],NULL);
    }

    return 0;
}

// void is_log(int client_no)
// {
// }

void process_command(vector<string> to_process, int client_no)
{
    char buffer[512];
    bzero(buffer,512);
    if(to_process[0] == "create_user")
    {
        if(to_process.size() != 3){
        const char* s = "Incorrect Format";
        strcpy(buffer,s);
        send(client_no,buffer, strlen(buffer),0);
        return;
        }
        if(db.find(to_process[1])!=db.end())
        {
            const char* s = "User already exists";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }
        else
        {
            struct user_struct s1;
            s1.available=0;
            s1.password = to_process[2];
            s1.name = to_process[1];
            db[to_process[1]] = s1;
            const char* s = "User created successfully";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
        }
        // const char* s = "Something is not right";
        // strcpy(buffer,s);
        // send(client_no,buffer, strlen(buffer),0);
        // return;
    }
    

    if(to_process[0] == "login")
    {
        if(to_process.size() != 3){
        const char* s = "Incorrect Format";
        strcpy(buffer,s);
        send(client_no,buffer, strlen(buffer),0);
        return;
        }

        // db.find(to_process[1]) != db.end()
        if(current_users.find(client_no) != current_users.end())
        {
            if(db[to_process[1]].available == 1 && db[to_process[1]].password == to_process[2])
            {
                const char* s = "Someone already logged in with these credentials";
                strcpy(buffer,s);
                send(client_no,buffer, strlen(buffer),0);
                return;
            }
        }

        if(db.find(to_process[1]) == db.end())
        {
            const char* s = "User does not exists";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        if(db.find(to_process[1]) != db.end())
        {
            string pass = db[to_process[1]].password;
            string pass2 = to_process[2];
            if( pass == pass2)
            {
                vector< pair<string, string> > temp = track[client_no].vec;
                // db_group[to_process[1]].file_shareable[temp[i].second] == true
                for(int i=0;i<temp.size();i++)
                {
                    db_group[temp[i].first].file_shareable[temp[i].second] = true;
                }
                const char* s = "You are logged in";
                current_users[client_no] = to_process[1];
                strcpy(buffer,s);
                send(client_no,buffer, strlen(buffer),0);
                db[to_process[1]].available = 1;
                return;
            }

            else if(pass != pass2)
            {
                const char* s = "Enter correct password";
                // string x = pass+" "+pass2;
                // const char* s = x.c_str();
                strcpy(buffer,s);
                send(client_no,buffer, strlen(buffer),0);
                return;
            }
        }
        // const char* s = "Something is not right";
        // strcpy(buffer,s);
        // send(client_no,buffer, strlen(buffer),0);
        // return;
    }

    if(to_process[0] == "create_group")
    {
        if(to_process.size() != 2)
        {
            const char* s = "Enter correct command";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else if(current_users.find(client_no) == current_users.end())
        {
            const char* s = "You have to login to create group";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }
        
        else if(db_group.find(to_process[1]) != db_group.end())
        {
            const char* s = "Group already exists with this group_id, enter different group_id";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else
        {
            // int flag=0;
            struct group_struct s1;
            s1.clients.push_back(client_no);
            s1.admin_name = current_users[client_no];
            s1.group_id = to_process[1];
            s1.users = 1;
            // s1.users_name.push_back(s1.admin_name);
            // s1.users_name[client_no] = s1.admin_name;
            s1.users_name.push_back(s1.admin_name);
            db_group[to_process[1]] = s1;
            const char* s = "Group created successfully";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }
        const char* s = "Something is not right";
        strcpy(buffer,s);
        send(client_no,buffer, strlen(buffer),0);
        return;
    }

    if(to_process[0] == "join_group")
    {
        if(to_process.size() != 2)
        {
            const char* s = "Enter correct command";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else if(current_users.find(client_no) == current_users.end())
        {
            const char* s = "You have to login to join group";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else if(db_group.find(to_process[1]) == db_group.end())
        {
            const char* s = "No such group exists with this group_id";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else
        {
            if(db_group.find(to_process[1]) != db_group.end())
            {
                vector<int> t = db_group[to_process[1]].clients;
                // string x1;
                // int flag=0;
                for(int i=0;i<t.size();i++)
                {
                    if(t[i] == client_no)
                    {
                        const char* s = "You are already present in this group";
                        strcpy(buffer,s);
                        send(client_no,buffer, strlen(buffer),0);
                        return;
                    }
                }
                group_requests[to_process[1]].user_id.push_back(current_users[client_no]);
                const char* s = "Request send for joining group";
                strcpy(buffer,s);
                send(client_no,buffer, strlen(buffer),0);
                return;
            }
        }
        const char* s = "Something is not right";
        strcpy(buffer,s);
        send(client_no,buffer, strlen(buffer),0);
        return;
    }

    if(to_process[0] == "leave_group")
    {
        if(to_process.size() != 2)
        {
            const char* s = "Enter correct command";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else if(current_users.find(client_no) == current_users.end())
        {
            const char* s = "You have to login to leave group";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else if(db_group.find(to_process[1]) == db_group.end())
        {
            const char* s = "No such group exists with this group_id";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else
        {
            if(db_group.find(to_process[1]) != db_group.end())
            {
                vector<int> t1 = db_group[to_process[1]].clients;
                vector<string> t2 = db_group[to_process[1]].users_name;
                for(int i=0;i<t1.size();i++)
                {
                    if(t1[i] == client_no)
                    {
                        t1[i] = -1;
                        db_group[to_process[1]].users--;
                        for(int j=0;j<t2.size();j++)
                        {
                            if(t2[j] == current_users[client_no])
                            t2[j] = "-1";
                        }
                        vector< pair<string, string> > temp = track[client_no].vec;
                        // db_group[to_process[1]].file_shareable[temp[i].second] == true
                        for(int i=0;i<temp.size();i++)
                        {
                            if(temp[i].first == to_process[1])
                            {
                                db_group[to_process[1]].file_shareable.erase(temp[i].second);
                                //db_group[to_process[1]].file_names.erase(temp[i].second);
                                vector< pair <string, string>> t = db_group[to_process[1]].file_names;
                                for(int j=0;j<t.size();j++)
                                {
                                    if(t[j].first == temp[i].second)
                                    {
                                        db_group[to_process[1]].file_names.erase(db_group[to_process[1]].file_names.begin()+j);
                                    }
                                }
                            }
                        }
                        string to_send = "You left group "+db_group[to_process[1]].group_id+". Now group have "+ to_string(db_group[to_process[1]].users) +" members left";
                        if(db_group[to_process[1]].users == 0)
                        {
                            db_group.erase(to_process[1]);
                        }
                        const char* s = to_send.c_str();
                        strcpy(buffer,s);
                        send(client_no,buffer, strlen(buffer),0);
                        return;

                    }
                }
                const char* s = "You are not part of this group";
                strcpy(buffer,s);
                send(client_no,buffer, strlen(buffer),0);
                return;
            }
        }
        const char* s = "Something is not right";
        strcpy(buffer,s);
        send(client_no,buffer, strlen(buffer),0);
        return;
    }

    if(to_process[0] == "list_groups")
    {
        if(to_process.size() != 1)
        {
            const char* s = "Enter correct command";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else if(current_users.find(client_no) == current_users.end())
        {
            const char* s = "You have to login to list groups";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        // else if(db_group.find(to_process[1]) == db_group.end())
        // {
        //     const char* s = "No such group exists with this group_id";
        //     strcpy(buffer,s);
        //     send(client_no,buffer, strlen(buffer),0);
        //     return;
        // }

        else
        {
            string x="\n";
            // int no_of_group=1;
            for(auto it : db_group)
            {
                x += it.second.group_id+"\n";
                // no_of_group++;
            }

            const char* s = x.c_str();
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }
        const char* s = "Something is not right";
        strcpy(buffer,s);
        send(client_no,buffer, strlen(buffer),0);
        return;
    }

    if(to_process[0] == "requests")
    {
        if(to_process.size() != 3 || to_process[1] != "list_requests")
        {
            const char* s = "Enter correct command";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else if(current_users.find(client_no) == current_users.end())
        {
            const char* s = "You have to login to list requests";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else if(db_group.find(to_process[2]) == db_group.end())
        {
            const char* s = "No such group exists with this group_id";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else
        {
            string x="\n";
            if(group_requests.find(to_process[2]) == group_requests.end())
            {
                const char* s = "No such group exists with provided group_id";
                strcpy(buffer,s);
                send(client_no,buffer, strlen(buffer),0);
                return;
            }
            vector<string> temp = group_requests[to_process[2]].user_id;
            for(int i=0;i<temp.size();i++)
            {
                x += temp[i]+"\n";
            }
            const char* s = x.c_str();
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        const char* s = "Something is not right";
        strcpy(buffer,s);
        send(client_no,buffer, strlen(buffer),0);
        return;
    }

    if(to_process[0] == "logout")
    {
        if(to_process.size() != 1)
        {
            const char* s = "Enter correct command";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else if(current_users.find(client_no) == current_users.end())
        {
            const char* s = "You have to first login to logout";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else
        {
            string x = current_users[client_no];
            db[x].available=0;
            vector< pair<string, string> > temp = track[client_no].vec;
            // db_group[to_process[1]].file_shareable[temp[i].second] == true
            for(int i=0;i<temp.size();i++)
            {
                db_group[temp[i].first].file_shareable[temp[i].second] = false;
            }
            current_users.erase(client_no);
            const char* s = "You are logged out, bye!";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }
        const char* s = "Something is not right";
        strcpy(buffer,s);
        send(client_no,buffer, strlen(buffer),0);
        return;
    }

    if(to_process[0] == "accept_request")
    {
        if(to_process.size() != 3)
        {
            const char* s = "Enter correct command";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }
        else if(current_users.find(client_no) == current_users.end())
        {
            const char* s = "You have to login to accept requests";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else if(db_group.find(to_process[1]) == db_group.end())
        {
            const char* s = "No such group exists with this group_id";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        vector<string> temp = group_requests[to_process[1]].user_id;
        int flag=0;
        for(int i=0;i<temp.size();i++)
        {
            if(temp[i] == to_process[2])
            {
                flag=1;
                break;
            }
        }

        if(flag == 0)
        {
            const char* s = "First send joining request";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }
        else
        {
            if(db_group[to_process[1]].admin_name != current_users[client_no])
            {
                const char* s = "Only admin can decide, you are not admin";
                strcpy(buffer,s);
                send(client_no,buffer, strlen(buffer),0);
                return;
            }
            db_group[to_process[1]].users++;
            // db_group[to_process[1]].client_no = client_no;
            int t1;
            for(auto it : current_users)
            {
                if(it.second == to_process[2])
                t1 = it.first;
            }
            db_group[to_process[1]].clients.push_back(t1);
            db_group[to_process[1]].users_name.push_back(to_process[2]);
            // db_group[to_process[1]].users_name[client_no] = to_process[2];
            string x = to_process[2]+" is added to group "+to_process[1];
            const char* s = x.c_str();
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        const char* s = "Something is not right";
        strcpy(buffer,s);
        send(client_no,buffer, strlen(buffer),0);
        return;
    }

    if(to_process[0] == "upload_file")
    {
        if(to_process.size() != 3)
        {
            const char* s = "Enter correct command";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        // check logged in or not 
        // check group exists or not

        else if(current_users.find(client_no) == current_users.end())
        {
            const char* s = "You have to login to upload files";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else if(db_group.find(to_process[2]) == db_group.end())
        {
            const char* s = "No such group exists with this group_id";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else 
        {   
            string path = to_process[1];
            reverse(path.begin(),path.end());
            string filename="";
            for(int i=0;i<path.size();i++)
            {
                if(path[i] == '/')
                break;
                else
                filename.push_back(path[i]);
            }
            reverse(filename.begin(),filename.end());
            track[client_no].vec.push_back(make_pair(to_process[2],filename));
            db_group[to_process[2]].file_shareable[filename] = true;
            db_group[to_process[2]].file_names.push_back(make_pair(filename,to_process[1]));
            const char* s = "Your file is uploaded";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }
        const char* s = "Something is not right";
        strcpy(buffer,s);
        send(client_no,buffer, strlen(buffer),0);
        return;

    }

    if(to_process[0] == "list_files")
    {
        if(to_process.size() != 2)
        {
            const char* s = "Enter correct command";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        //check loggedin or not
        // make function to check login or group present or not

        else if(current_users.find(client_no) == current_users.end())
        {
            const char* s = "You have to login to list files";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else if(db_group.find(to_process[1]) == db_group.end())
        {
            const char* s = "No such group exists with this group_id";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else
        {
            string to_send="\n";
            vector< pair <string, string>> temp = db_group[to_process[1]].file_names;
            for(int i=0;i<temp.size();i++)
            {
                if(db_group[to_process[1]].file_shareable[temp[i].first] == true)
                to_send += temp[i].first+"\n";
            }
            const char *s = to_send.c_str();
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        const char* s = "Something is not right";
        strcpy(buffer,s);
        send(client_no,buffer, strlen(buffer),0);
        return;
    }

    if(to_process[0] == "stop_share")
    {
        if(to_process.size() != 3)
        {
            const char* s = "Enter correct command";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }
        else if(current_users.find(client_no) == current_users.end())
        {
            const char* s = "You have to login first";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else if(db_group.find(to_process[1]) == db_group.end())
        {
            const char* s = "No such group exists with this group_id";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }

        else
        {
            vector<pair<string,string>> v = track[client_no].vec;
            int flag =0;
            for(int i=0;i<v.size();i++)
            {
                if(v[i].second == to_process[2])
                flag=1;
            }

            if(flag == 0)
            {
                const char* s = "User does not have authority for this file ";
                strcpy(buffer,s);
                send(client_no,buffer, strlen(buffer),0);
                return;
            }

            // vector< pair<string, string> > temp = track[client_no].vec;
            // db_group[to_process[1]].file_shareable[temp[i].second] == true
            for(int i=0;i<v.size();i++)
            {
                if(v[i].first == to_process[1])
                {
                    db_group[to_process[1]].file_shareable.erase(v[i].second);
                    //db_group[to_process[1]].file_names.erase(temp[i].second);
                    vector< pair <string, string>> t = db_group[to_process[1]].file_names;
                    for(int j=0;j<t.size();j++)
                    {
                        if(t[j].first == to_process[2])
                        {
                            db_group[to_process[1]].file_names.erase(db_group[to_process[1]].file_names.begin()+j);
                        }
                    }
                }
            }

            // db_group[to_process[1]].file_shareable.erase(to_process[2]);
            const char* s = "You file is now not shareable";
            strcpy(buffer,s);
            send(client_no,buffer, strlen(buffer),0);
            return;
        }
    }


}

void* handle_connection(void* pclient_socket)
{
    int client_socket = *((int*)pclient_socket);
    free(pclient_socket);
    char buffer[512];
    size_t bytes_read;
    int msgsize = 0;
    char *actualpath;

    while(1)
    {
        bzero(buffer,512);
        recv(client_socket,buffer,sizeof(buffer),0);
        vector<string> to_process;
        string x;
        for(int i=0;;i++)
        {
            if(buffer[i] == '\0')
            break;
            if(buffer[i] == ' '){
            to_process.push_back(x);
            x="";
            }
            else
            x.push_back(buffer[i]);
        }
        to_process.push_back(x);
        // for(int i=0;i<to_process.size();i++)
        // cout<<to_process[i];
        process_command(to_process,client_socket);
    }
    close(client_socket);
    //fclose(fp);
    return NULL;
}