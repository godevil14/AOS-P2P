#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <pthread.h>
// #include <string>
#include <iostream>
#include <string>
#include <bits/stdc++.h>
#include <curses.h>
#include <sstream>

using namespace std;

int main(int argc, char *argv[])
{


    // char ch;
    // file_p = fopen("temp1.txt","w");
    // if(argc < 3)
    // {
    //     cout<<"Run properly";
    //     exit(-1);
    // }

    string ip_port = argv[1];
    string port_add;
    string ip;
    for(int i=0;i<ip_port.size();i++)
    {
        if(ip_port[i] == ':')
        {
            for(int j=i+1;j<ip_port.size();j++)
            port_add.push_back(ip_port[j]);
            break;
        }
        else
        {
            ip.push_back(ip_port[i]);
        }
    }

    stringstream geek(port_add);
    int port = 0;
    geek >> port;

    const char* add = ip.c_str();
    // int port = 5000; 
    int clients;
    struct sockaddr_in client_addr;
    socklen_t addr_size;
    char message[512];

    clients = socket(AF_INET, SOCK_STREAM, 0);
    if(clients<=-1)
    {
        perror("Error");
        exit(1);
    }
    printf("Server connected\n");

    memset(&client_addr,'\0', sizeof(client_addr));

    client_addr.sin_family = AF_INET;
    client_addr.sin_port=port;
    client_addr.sin_addr.s_addr = inet_addr(add);


    // int id=1;
    connect(clients, (struct sockaddr*)&client_addr, sizeof(client_addr));
    cout<<"hello"<<endl;
    while(1)
    {
        bzero(message,512);
        // recv(clients,message,sizeof(message),0);
        // if(sizeof(message))
        // printf("Server: %s\n",message);

        // bzero(message,512);
        char c = getchar();
        int i=0;
        if(c)
        {
            while(c != '\n')
            {

                message[i] = c;
                i++;
                c = getchar();
            }
            message[i] = '\0';
            send(clients,message, strlen(message),0);
        }
        // fprintf(file_p,"%s",message);
        // printf("Server: %s\n",message);
        bzero(message,512);
        recv(clients,message,sizeof(message),0);
        if(sizeof(message))
        printf("Server: %s\n",message);
        // id = strlen(message);
    }
    close(clients);
    return 0;
}
